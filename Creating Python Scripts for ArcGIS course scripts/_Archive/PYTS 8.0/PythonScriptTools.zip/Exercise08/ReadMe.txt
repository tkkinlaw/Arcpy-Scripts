In this exercise, students add a new map called ScriptTool to the PowerOutage project. Students also add a script tool to the Default.atbx toolbox and run the tool in the Geoprocessing pane.

The script tool that is created in this exercise is used by students in Exercise 9 and Exercise 10.

Note: The geoprocessing result, which is created when the tool is run, is stored in the project and used by students in Exercise 10.