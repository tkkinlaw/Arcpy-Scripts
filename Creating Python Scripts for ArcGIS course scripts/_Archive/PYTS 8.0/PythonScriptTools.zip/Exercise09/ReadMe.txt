In this exercise, students use the PowerOutage project to update the validation settings for the script tool that was created in Exercise 8.

The updated script tool is not used by subsequent exercises.