In this exercise, students share a geoprocessing result as a geoprocessing package.

The results of this exercise are not used by subsequent exercises because this is the last exercise in the course.